plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.slodi.scores"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.slodi.scores"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Do NOT hardcode real API keys for production.
        // For quick testing you can set API_FOOTBALL_KEY here, but the recommended way:
        // 1) Put: API_FOOTBALL_KEY=YOUR_KEY in local.properties
        // 2) Sync Gradle, it will be read below.
        val localProps = java.util.Properties()
        val localFile = rootProject.file("local.properties")
        val apiKey = if (localFile.exists()) {
            localProps.load(localFile.inputStream())
            localProps.getProperty("API_FOOTBALL_KEY") ?: "YOUR_KEY_HERE"
        } else {
            "YOUR_KEY_HERE"
        }
        buildConfigField("String", "API_FOOTBALL_KEY", "\"$apiKey\"")
        buildConfigField("String", "API_BASE_URL", "\"https://v3.football.api-sports.io\"")
        // Saudi Pro League (often 307 in API-Football). You can change from Settings inside the app.
        buildConfigField("Int", "DEFAULT_LEAGUE_ID", "307")
    }

    buildFeatures {
        buildConfig = true
        viewBinding = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        resources.excludes.add("META-INF/{AL2.0,LGPL2.1}")
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")

    // Networking
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // JSON parsing
    implementation("org.json:json:20240303")

    // Lifecycle
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
}
