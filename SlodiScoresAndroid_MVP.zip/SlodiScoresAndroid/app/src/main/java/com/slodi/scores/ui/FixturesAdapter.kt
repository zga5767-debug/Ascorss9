package com.slodi.scores.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.slodi.scores.data.Fixture
import com.slodi.scores.databinding.ItemFixtureBinding

class FixturesAdapter : RecyclerView.Adapter<FixturesAdapter.VH>() {
    private val items = ArrayList<Fixture>()

    fun submit(list: List<Fixture>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemFixtureBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        holder.bind(items[position])
    }

    class VH(private val b: ItemFixtureBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(f: Fixture) {
            b.tvTeams.text = "${f.home}  vs  ${f.away}"
            b.tvScore.text = "${f.homeGoals} - ${f.awayGoals}"
            b.tvMeta.text = "${f.time} • ${f.status}"
        }
    }
}
