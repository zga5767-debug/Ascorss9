package com.slodi.scores.data

data class Fixture(
    val home: String,
    val away: String,
    val homeGoals: Int,
    val awayGoals: Int,
    val time: String,
    val status: String
)
