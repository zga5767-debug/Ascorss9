package com.slodi.scores.ui

import android.content.Context
import android.util.AttributeSet
import android.view.Gravity
import android.widget.FrameLayout
import android.widget.TextView
import com.google.android.material.color.MaterialColors
import com.slodi.scores.R

/**
 * Simple placeholder where you will later integrate AdMob Native/Banner.
 * Keeps the MVP AdSense/AdMob-safe by not injecting any 3rd-party scripts.
 */
class AdPlaceholderView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    init {
        val tv = TextView(context).apply {
            text = resources.getString(R.string.ad_placeholder)
            gravity = Gravity.CENTER
            setPadding(16, 16, 16, 16)
        }
        val stroke = MaterialColors.getColor(this, com.google.android.material.R.attr.colorOutline)
        setBackgroundResource(R.drawable.bg_ad_placeholder)
        addView(tv, LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT))
        // stroke is defined in drawable; this line avoids lint unused
        tv.setTextColor(MaterialColors.getColor(this, com.google.android.material.R.attr.colorOnSurface))
        tv.alpha = 0.8f
    }
}
