package com.slodi.scores.data

import com.slodi.scores.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.IOException

class ApiFootballService {
    private val client = OkHttpClient()

    /**
     * Fetch fixtures for a given league and date (YYYY-MM-DD).
     * Note: API key is read from BuildConfig.API_FOOTBALL_KEY.
     */
    @Throws(IOException::class)
    fun getFixtures(leagueId: Int, season: Int, date: String): String {
        val url = "${BuildConfig.API_BASE_URL}/fixtures?league=$leagueId&season=$season&date=$date"
        val req = Request.Builder()
            .url(url)
            .addHeader("x-apisports-key", BuildConfig.API_FOOTBALL_KEY)
            .build()

        client.newCall(req).execute().use { res ->
            if (!res.isSuccessful) {
                throw IOException("API error ${res.code}: ${res.body?.string()}")
            }
            return res.body?.string() ?: "{}"
        }
    }

    fun parseFixtures(json: String): List<Fixture> {
        val root = JSONObject(json)
        val arr = root.optJSONArray("response") ?: return emptyList()
        val out = ArrayList<Fixture>(arr.length())
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            val teams = it.optJSONObject("teams")
            val goals = it.optJSONObject("goals")
            val fixture = it.optJSONObject("fixture")

            val home = teams?.optJSONObject("home")?.optString("name", "Home") ?: "Home"
            val away = teams?.optJSONObject("away")?.optString("name", "Away") ?: "Away"

            val homeGoals = goals?.optInt("home", 0) ?: 0
            val awayGoals = goals?.optInt("away", 0) ?: 0

            val statusShort = fixture?.optJSONObject("status")?.optString("short", "") ?: ""
            val dateStr = fixture?.optString("date", "") ?: ""
            val time = if (dateStr.length >= 16) dateStr.substring(11, 16) else ""

            out.add(
                Fixture(
                    home = home,
                    away = away,
                    homeGoals = homeGoals,
                    awayGoals = awayGoals,
                    time = time,
                    status = statusShort
                )
            )
        }
        return out
    }
}
