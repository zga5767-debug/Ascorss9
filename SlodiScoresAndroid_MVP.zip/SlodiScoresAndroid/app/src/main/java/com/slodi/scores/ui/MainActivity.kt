package com.slodi.scores.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.snackbar.Snackbar
import com.slodi.scores.BuildConfig
import com.slodi.scores.R
import com.slodi.scores.data.ApiFootballService
import com.slodi.scores.databinding.ActivityMainBinding
import com.slodi.scores.util.Prefs
import com.slodi.scores.util.ThemeUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.time.LocalDate

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private val adapter = FixturesAdapter()
    private val api = ApiFootballService()

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(Prefs.getThemeMode(this))
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        setSupportActionBar(b.toolbar)
        b.toolbar.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.action_settings -> {
                    startActivity(Intent(this, SettingsActivity::class.java))
                    true
                }
                else -> false
            }
        }
        b.toolbar.inflateMenu(R.menu.menu_main)

        b.recycler.layoutManager = LinearLayoutManager(this)
        b.recycler.adapter = adapter

        b.swipe.setOnRefreshListener {
            loadFixtures(forceRefresh = true)
        }

        loadFixtures(forceRefresh = false)
    }

    override fun onResume() {
        super.onResume()
        // Re-apply theme if changed in settings
        ThemeUtil.apply(Prefs.getThemeMode(this))
        // Optional refresh after returning
    }

    private fun loadFixtures(forceRefresh: Boolean) {
        b.swipe.isRefreshing = true
        lifecycleScope.launch {
            val leagueId = Prefs.getLeagueId(this@MainActivity, BuildConfig.DEFAULT_LEAGUE_ID)
            val today = LocalDate.now().toString()
            val season = LocalDate.now().year

            try {
                val data = withContext(Dispatchers.IO) {
                    val (cachedJson, cachedAt) = Prefs.getCache(this@MainActivity)
                    val now = System.currentTimeMillis()
                    val cacheValid = (now - cachedAt) < 60_000L // 60 sec

                    val json = if (!forceRefresh && cacheValid && cachedJson != null) {
                        cachedJson
                    } else {
                        val fresh = api.getFixtures(leagueId, season, today)
                        Prefs.setCache(this@MainActivity, fresh, now)
                        fresh
                    }
                    api.parseFixtures(json)
                }

                adapter.submit(data)
                if (data.isEmpty()) {
                    Snackbar.make(b.root, "لا توجد مباريات اليوم", Snackbar.LENGTH_SHORT).show()
                }
            } catch (e: IOException) {
                Snackbar.make(b.root, "خطأ في الاتصال أو API: ${e.message}", Snackbar.LENGTH_LONG).show()
            } catch (e: Exception) {
                Snackbar.make(b.root, "خطأ: ${e.message}", Snackbar.LENGTH_LONG).show()
            } finally {
                b.swipe.isRefreshing = false
            }
        }
    }
}
