package com.slodi.scores.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.slodi.scores.databinding.ActivitySettingsBinding
import com.slodi.scores.util.Prefs
import com.slodi.scores.util.ThemeUtil

class SettingsActivity : AppCompatActivity() {

    private lateinit var b: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtil.apply(Prefs.getThemeMode(this))
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)

        b.toolbar.setNavigationOnClickListener { finish() }
        b.toolbar.navigationIcon = getDrawable(androidx.appcompat.R.drawable.abc_ic_ab_back_material)

        val mode = Prefs.getThemeMode(this)
        when (mode) {
            "light" -> b.toggleTheme.check(b.btnLight.id)
            "dark" -> b.toggleTheme.check(b.btnDark.id)
            else -> b.toggleTheme.check(b.btnSystem.id)
        }

        b.toggleTheme.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (!isChecked) return@addOnButtonCheckedListener
            val newMode = when (checkedId) {
                b.btnLight.id -> "light"
                b.btnDark.id -> "dark"
                else -> "system"
            }
            Prefs.setThemeMode(this, newMode)
            ThemeUtil.apply(newMode)
        }
    }
}
