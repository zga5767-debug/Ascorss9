package com.slodi.scores.util

import android.content.Context

object Prefs {
    private const val FILE = "slodi_scores_prefs"
    private const val KEY_THEME = "theme_mode" // system/light/dark
    private const val KEY_LEAGUE_ID = "league_id" // Int
    private const val KEY_CACHE_JSON = "cache_json"
    private const val KEY_CACHE_TIME = "cache_time"

    fun getThemeMode(ctx: Context): String {
        return ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getString(KEY_THEME, "system") ?: "system"
    }

    fun setThemeMode(ctx: Context, mode: String) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putString(KEY_THEME, mode).apply()
    }

    fun getLeagueId(ctx: Context, defaultId: Int): Int {
        return ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .getInt(KEY_LEAGUE_ID, defaultId)
    }

    fun setLeagueId(ctx: Context, leagueId: Int) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit().putInt(KEY_LEAGUE_ID, leagueId).apply()
    }

    fun getCache(ctx: Context): Pair<String?, Long> {
        val p = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return p.getString(KEY_CACHE_JSON, null) to p.getLong(KEY_CACHE_TIME, 0L)
    }

    fun setCache(ctx: Context, json: String, timeMs: Long) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_CACHE_JSON, json)
            .putLong(KEY_CACHE_TIME, timeMs)
            .apply()
    }
}
