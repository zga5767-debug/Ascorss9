# Slodi Scores (Android MVP)

تطبيق أندرويد خفيف جدًا لعرض **مباريات اليوم** (Fixtures) مع **Dark Mode** وبنية جاهزة لوضع إعلانات AdMob (Placeholder فقط).

## مهم (الأمان)
- المفتاح الذي أرسلته في الدردشة تم اعتباره **مكشوفًا**. قم بعمل **Regenerate** في لوحة API-Football.
- **لا تضع API Key داخل الكود للإطلاق**. على الأقل ضعه في `local.properties`، والأفضل في Backend Proxy.

## إضافة API Key (للتجربة فقط)
افتح ملف `local.properties` في جذر المشروع (إن لم يوجد أنشئه) وأضف:

```
API_FOOTBALL_KEY=YOUR_KEY_HERE
```

ثم Sync Gradle.

## تشغيل المشروع
1) افتح المشروع في Android Studio (Giraffe/Koala أو أحدث)
2) Gradle Sync
3) Run على جهاز أندرويد

## بناء APK
من Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

## أين تضع AdMob لاحقًا؟
- `AdPlaceholderView` في `ui/AdPlaceholderView.kt` هو المكان البديل.
- في `activity_main.xml` يوجد Placeholder أعلى وأسفل.

## تغيير الدوري
حاليًا مضبوط على `DEFAULT_LEAGUE_ID = 307` (غالبًا الدوري السعودي). إذا اختلف عندك، عدّل الرقم في `app/build.gradle.kts`.

